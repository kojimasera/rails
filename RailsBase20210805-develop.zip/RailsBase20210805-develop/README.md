# RailsBase20210805
Docker＋Rails6＋MySQLのベース環境構築

## git コマンド

### 初期設定(※developのクローン作成)
```
git clone -b develop git clone -b develop https://github.com/kazuhisa-nakama/RailsBase20210805.git
```
